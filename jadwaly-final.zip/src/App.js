import TeacherDashboard from './components/TeacherDashboard';

function App() {
  return <TeacherDashboard />;
}

export default App;
